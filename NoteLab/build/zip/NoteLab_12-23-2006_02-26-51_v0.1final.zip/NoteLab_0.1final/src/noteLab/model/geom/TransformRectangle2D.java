/*
 *  NoteLab:  An advanced note taking application for pen-enabled platforms
 *  
 *  Copyright (C) 2006, Dominic Kramer
 *  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *  
 *  For any questions or comments please contact:  
 *    Dominic Kramer
 *    kramerd@iastate.edu
 */

package noteLab.model.geom;

import java.awt.Rectangle;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.Vector;

import noteLab.util.geom.Bounded;
import noteLab.util.geom.Transformable;
import noteLab.util.mod.ModBroadcaster;
import noteLab.util.mod.ModListener;
import noteLab.util.mod.ModType;

/**
 * An implementation of a rectangle that is both bounded and transformable.  
 * That is, the bounds of the rectangle can be acquired and the 
 * rectangle can be scaled and translated.
 * 
 * @author Dominic Kramer
 */
public class TransformRectangle2D 
                extends Rectangle.Float 
                           implements Bounded, Transformable, 
                                      ModBroadcaster
{
   /** The amount this rectangle was scaled in the x direction. */
   protected float xScaleLevel;
   
   /** The amount this rectangle was scaled in the y direction. */
   protected float yScaleLevel;
   
   /**
    * The vector of listeners that are notified when this rectangle 
    * is modified.
    */
   protected Vector<ModListener> modListenerVec;
   
   /**
    * Constructs a rectangle with its values initialized from the 
    * given rectangle.
    * 
    * @param rect The rectangle on which this rectangle is based.
    * @param xScaleLevel The amount this rectangle was scaled at 
    *                    in the x direction at the time this 
    *                    rectangle was constructed.
    * @param yScaleLevel The amount this rectangle was scaled at 
    *                    in the y direction at the time this 
    *                    rectangle was constructed.
    */
   public TransformRectangle2D(Rectangle2D.Float rect, 
                               float xScaleLevel, float yScaleLevel)
   {
      this(rect.x, rect.y, rect.width, rect.height, 
           xScaleLevel, yScaleLevel);
   }
   
   /**
    * Constructs a rectangle with the given parameters.
    * 
    * @param pt The upper-left corner of this rectangle.
    * @param w The width of this rectangle.
    * @param h The height of this rectangle.
    * @param xScaleLevel The amount this rectangle was scaled at 
    *                    in the x direction at the time this 
    *                    rectangle was constructed.
    * @param yScaleLevel The amount this rectangle was scaled at 
    *                    in the y direction at the time this 
    *                    rectangle was constructed.
    */
   public TransformRectangle2D(Point2D.Float pt, float w, float h, 
                               float xScaleLevel, float yScaleLevel)
   {
      this(pt.x, pt.y, w, h, xScaleLevel, yScaleLevel);
   }
   
   /**
    * Constructs a rectangle with the given parameters.
    * 
    * @param x The x coordinate of the upper-left corner of this rectangle.
    * @param y The y coordinate of the upper-left corner of this rectangle.
    * @param w The width of this rectangle.
    * @param h The height of this rectangle.
    * @param xScaleLevel The amount this rectangle was scaled at 
    *                    in the x direction at the time this 
    *                    rectangle was constructed.
    * @param yScaleLevel The amount this rectangle was scaled at 
    *                    in the y direction at the time this 
    *                    rectangle was constructed.
    */
   public TransformRectangle2D(float x, float y, float w, float h, 
                               float xScaleLevel, float yScaleLevel)
   {
      super(x, y, w, h);
      
      this.modListenerVec = new Vector<ModListener>();
      
      this.xScaleLevel = xScaleLevel;
      this.yScaleLevel = yScaleLevel;
   }
   
   /**
    * Scales this rectangle by the given scaling factor.
    * 
    * @param x The amount this rectangle is scaled in the x direction.
    * @param y The amount this rectangle is scaled in the y direction.
    */
   public void scaleBy(float x, float y)
   {
      this.x *= x;
      this.y *= y;
      
      this.width *= x;
      this.height *= y;
      
      this.xScaleLevel *= x;
      this.yScaleLevel *= y;
      
      notifyModListeners(ModType.ScaleBy);
   }
   
   /**
    * Scales this rectangle to the given scale values.
    * 
    * @param x The amount this rectangle should be scaled to in 
    *          the x direction.
    * @param y The amount this rectangle should be scaled to in 
    *          the y direction.
    */
   public void scaleTo(float x, float y)
   {
      float xScaleTo = 1;
      float yScaleTo = 1;
      
      try
      {
         xScaleTo = x/this.xScaleLevel;
         yScaleTo = y/this.yScaleLevel;
      }
      catch (ArithmeticException e)
      {
         System.err.println(FloatPoint2D.class.getName()+" Warning:  " +
                            "cannot scale to the level ("+x+", "+y+") " +
                            "because this object has been scaled down " +
                            "beyond this machines floating point delta.");
      }
      
      this.x *= xScaleTo;
      this.y *= yScaleTo;
      
      this.width *= xScaleTo;
      this.height *= yScaleTo;
      
      this.xScaleLevel = x;
      this.yScaleLevel = y;
      
      notifyModListeners(ModType.ScaleTo);
   }
   
   /**
    * Translates this rectangle by the given amount.
    * 
    * @param x The amount the rectangle should be translated in 
    *          the x direction.
    * @param y The amount the rectangle should be translated in 
    *          the y direction.
    */
   public void translateBy(float x, float y)
   {
      this.x += x;
      this.y += y;
      
      notifyModListeners(ModType.TranslateBy);
   }
   
   /**
    * Translates this rectangle to the given coordinates.
    * 
    * @param x The new x coordinate of this rectangle's upper 
    *          left corner.
    * @param y The new y coordinate of this rectangle's upper 
    *          left corner.
    */
   public void translateTo(float x, float y)
   {
      this.x = x;
      this.y = y;
      
      notifyModListeners(ModType.TranslateTo);
   }
   
   /**
    * Used to add a listener that is notified when this rectangle is 
    * modified.
    * 
    * @param listener The listener to add.
    */
   public void addModListener(ModListener listener)
   {
      if (listener == null)
         throw new NullPointerException();
      
      if (!this.modListenerVec.contains(listener))
         this.modListenerVec.add(listener);
   }
   
   /**
    * Used to removed a listener from the list of listeners that are 
    * notified when this rectangle is modified.
    * 
    * @param listener The listener to remove.
    */
   public void removeModListener(ModListener listener)
   {
      if (listener == null)
         throw new NullPointerException();
      
      this.modListenerVec.remove(listener);
   }
   
   /**
    * Informs all of the ModListeners that this rectangle has been modified.
    * 
    * @param type The type of modification.
    */
   protected void notifyModListeners(ModType type)
   {
      for (ModListener listener : this.modListenerVec)
         listener.modOccured(this, type);
   }
   
   /**
    * Testbed.
    * 
    * @param args Unused.
    */
   public static void main(String[] args)
   {
      TransformRectangle2D rect = new TransformRectangle2D(0, 0, 1, 1, 1, 1);
      
      System.out.println("rect = "+rect);
      
      float xScale = 0.5f;
      float yScale = 0.5f;
      
      rect.scaleBy(xScale, yScale);
      System.out.println(" scale by ("+xScale+", "+yScale+") = "+rect);
      
      rect.scaleBy(xScale, yScale);
      System.out.println(" scale by ("+xScale+", "+yScale+") = "+rect);
   }
}
