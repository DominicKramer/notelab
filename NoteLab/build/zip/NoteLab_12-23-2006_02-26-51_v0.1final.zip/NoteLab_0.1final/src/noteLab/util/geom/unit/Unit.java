/*
 *  NoteLab:  An advanced note taking application for pen-enabled platforms
 *  
 *  Copyright (C) 2006, Dominic Kramer
 *  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *  
 *  For any questions or comments please contact:  
 *    Dominic Kramer
 *    kramerd@iastate.edu
 */

package noteLab.util.geom.unit;

import java.awt.Toolkit;

/**
 * This class serves to formally define a list of known units.
 * 
 * @author Dominic Kramer
 */
public enum Unit
{
   /** Defines that a value is in terms of pixels. */
   PIXEL, 
   
   /** Defines that a value is in terms of inches. */
   INCH, 
   
   /** Defines that a value is in terms of centimeters. */
   CM;
   
   /** Specifies the conversion ratio from pixels to inches. */
   private static final int PIXEL_PER_INCH = //96;//75;
                               Toolkit.getDefaultToolkit().
                                          getScreenResolution();
   
   /** Specifies the conversion ratio from centimeters to inches. */
   private static final float CM_PER_INCH = 2.54f;
   
   @Override
   public String toString()
   {
      switch (this)
      {
         case PIXEL:
            return "px";
         case INCH:
            return "in";
         case CM:
            return "cm";
         default:
            return "";
      }
   }
   
   /**
    * Given a value and the current unit that it is represented in, this 
    * method is used to get the value converted in terms of the new unit 
    * specified.
    * 
    * @param curVal The value to convert.
    * @param curUnit The unit that the value is represented in.
    * @param newUnit The unit that the value should be converted in terms 
    *                of.
    * @return The specified value converted in terms of the new unit 
    *         specified.
    */
   public static float getValue(float curVal, 
                                Unit curUnit, 
                                Unit newUnit)
   {
      if (curUnit == newUnit)
         return curVal;
      
      if (curUnit == Unit.PIXEL)
      {
         if (newUnit == Unit.INCH)
            return curVal/PIXEL_PER_INCH;
         else 
            return CM_PER_INCH*curVal/PIXEL_PER_INCH;
      }
      else if (curUnit == Unit.CM)
      {
         if (newUnit == Unit.PIXEL)
            return (curVal/CM_PER_INCH)*PIXEL_PER_INCH;
         else
            return curVal/CM_PER_INCH;
      }
      else if (curUnit == Unit.INCH)
      {
         if (newUnit == Unit.PIXEL)
            return curVal*PIXEL_PER_INCH;
         else
            return curVal*CM_PER_INCH;
      }
      
      return Float.NaN;
   }
}
