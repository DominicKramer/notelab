/*
 *  NoteLab:  An advanced note taking application for pen-enabled platforms
 *  
 *  Copyright (C) 2006, Dominic Kramer
 *  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *  
 *  For any questions or comments please contact:  
 *    Dominic Kramer
 *    kramerd@iastate.edu
 */

package noteLab.util.state;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

import noteLab.util.state.value.MutableNumber;
import noteLab.util.state.value.NumberValue;


public class ObjectState<V extends StringRecordable>
{
   private static final String CLASS_SUFFIX = "_CLASSNAME";
   
   private Hashtable<String, V> table;
   private String comment;
   
   public ObjectState()
   {
      this("");
   }
   
   public ObjectState(String comment)
   {
      this.table = new Hashtable<String, V>();
      
      setComment(comment);
   }
   
   public static ObjectState load(File file) throws FileNotFoundException, 
                                                     IOException
   {
      ObjectState state = new ObjectState();
      
      Properties props = new Properties();
      props.load(new FileInputStream(file));
      
      Enumeration keys = props.keys();
      String keyStr = "";
      String valStr;
      String valClassStr = "";
      Class valClass;
      Object ob;
      StringRecordable value;
      while (keys.hasMoreElements())
      {
         try
         {
            keyStr = (String)keys.nextElement();
            if (keyStr.endsWith(CLASS_SUFFIX))
               continue;
            
            valStr = props.getProperty(keyStr);
            valClassStr = props.getProperty(keyStr+CLASS_SUFFIX);
         
            valClass = Class.forName(valClassStr);
            ob = valClass.newInstance();
            if ( !(ob instanceof StringRecordable) )
            {
               System.err.println("OptionsState:  An Object of type " + 
                                  valClass+" has been read that isn't of " +
                                  "type StringRecordable");
               continue;
            }
            
            value = (StringRecordable)
                       ((StringRecordable)ob).getValueFromString(valStr);
            state.putValue(keyStr, value);
         }
         catch (Exception e)
         {
            System.err.println("OptionsState:  Could not construct an object "+
                               "of type "+valClassStr);
            System.err.println("  Currently processing key: "+keyStr);
            System.err.println(e);
            e.printStackTrace();
         }
      }
      
      return state;
   }
   
   public String getComment()
   {
      return this.comment;
   }
   
   public void setComment(String comment)
   {
      if (comment == null)
         throw new NullPointerException();
      
      this.comment = comment;
   }
   
   public V getValue(String key)
   {
      return this.table.get(key);
   }
   
   public void putValue(String key, V value)
   {
      this.table.put(key, value);
   }
   
   public boolean containsKey(String key)
   {
      return this.table.containsKey(key);
   }
   
   public void save(File file) throws FileNotFoundException, 
                                      IOException
   {
      Properties props = new Properties();
      
      Enumeration keys = this.table.keys();
      String key;
      V value;
      while (keys.hasMoreElements())
      {
         key = keys.nextElement().toString();
         value = this.table.get(key);
         props.put(key, value.getStringFromValue());
         props.put(key+CLASS_SUFFIX, value.getClass().getName());
      }
      
      props.store(new FileOutputStream(file), this.comment);
   }
   
   @Override
   public String toString()
   {
      StringBuffer buffer = new StringBuffer();
      
      Enumeration<String> keys = this.table.keys();
      String key;
      while (keys.hasMoreElements())
      {
         key = keys.nextElement();
         
         buffer.append("Key:  ");
         buffer.append(key);
         buffer.append("\n");
         
         buffer.append("  Value:  ");
         buffer.append(getValue(key));
         buffer.append("\n");
         
         buffer.append("  Value:  ");
         buffer.append(getValue(key).getClass().getName());
         buffer.append("\n");
      }
      
      return buffer.toString();
   }
   
   public static void main(String[] args) throws FileNotFoundException, 
                                                 IOException
   {
      ObjectState<StringRecordable> state = 
         new ObjectState<StringRecordable>();
      
      state.putValue("Key1", 
                     new NumberValue(new MutableNumber(10.1)));
      state.putValue("Key2", 
                     new NumberValue(new MutableNumber(2)));
      state.putValue("Key3", 
                     new NumberValue(new MutableNumber(9.87)));
      state.putValue("Key4", 
                     new NumberValue(new MutableNumber(-5)));
      
      File file = new File("/home/kramer/temp.xml");
      state.save(file);
      
      ObjectState readState = load(file);
      System.out.println(readState);
      readState.save(new File("/home/kramer/temp2.xml"));
   }
}
