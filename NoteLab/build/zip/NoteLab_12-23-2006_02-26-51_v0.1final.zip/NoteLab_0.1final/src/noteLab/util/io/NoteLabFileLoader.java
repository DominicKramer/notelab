/*
 *  NoteLab:  An advanced note taking application for pen-enabled platforms
 *  
 *  Copyright (C) 2006, Dominic Kramer
 *  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *  
 *  For any questions or comments please contact:  
 *    Dominic Kramer
 *    kramerd@iastate.edu
 */

package noteLab.util.io;

import java.awt.Color;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import noteLab.model.Page;
import noteLab.model.Path;
import noteLab.model.Stroke;
import noteLab.model.Paper.PaperType;
import noteLab.model.binder.Binder;
import noteLab.model.binder.FlowBinder;
import noteLab.model.canvas.CompositeCanvas;
import noteLab.model.geom.FloatPoint2D;
import noteLab.model.tool.Pen;
import noteLab.util.InfoCenter;
import noteLab.util.geom.unit.Unit;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class NoteLabFileLoader extends DefaultHandler
{
   private static final String G_NAME = "g";
   private static final String ID_NAME = "id";
   private static final String DESC_NAME = "desc";
   private static final String FILL_NAME = "fill";
   private static final String STROKE_NAME = "stroke";
   private static final String STROKE_WIDTH_NAME = "stroke-width";
   
   private static final String RECT_TAG_NAME = "rect";
   private static final String LINE_TAG_NAME = "line";
   
   private static final float SCALE_LEVEL = 1;
   
   private File file;
   private NoteLabFileLoadedListener listener;
   
   private Binder curBinder;
   private Page curPage;
   private Stroke curStroke;
   
   private String lastID;
   
   public NoteLabFileLoader(File file, 
                            NoteLabFileLoadedListener listener) 
                               throws IOException
   {
      if (file == null || listener == null)
         throw new NullPointerException();
      
      String ext = InfoCenter.getFileExtension().toLowerCase();
      if (!file.getPath().toLowerCase().endsWith(ext))
         throw new IOException("The file '"+file.getAbsolutePath()+
                               "' is not a native "+InfoCenter.getAppName()+
                               " file (a file of type "+ext+").");
      
      this.file = file;
      this.listener = listener;
      
      this.curBinder = null;
      this.curPage = null;
      this.curStroke = null;
      
      this.lastID = null;
   }
   
   public void loadFile() throws ParserConfigurationException, 
                                 SAXException, 
                                 IOException
   {
      //create a parser factory
      SAXParserFactory parserFac = SAXParserFactory.newInstance();
      parserFac.setNamespaceAware(true);
      
      //get a parser
      SAXParser parser = parserFac.newSAXParser();
      
      //parse the xml document
      parser.parse(file, this);
   }
   
   @Override
   public void startElement(String uri, String localName, 
                            String qName, Attributes attributes) 
                               throws SAXException
   {
      super.startElement(uri, localName, qName, attributes);
      
      if (localName.equals(G_NAME))
      {
         String id = attributes.getValue(ID_NAME);
         this.lastID = id;
         if (id == null)
            return;
         
         if (id.equals(Page.class.getName()))
         {
            this.curPage = new Page(getPaperType(attributes), 
                                    SCALE_LEVEL, 
                                    SCALE_LEVEL);
            
            if (this.curBinder == null)
               this.curBinder = new FlowBinder(SCALE_LEVEL, 
                                               SCALE_LEVEL, 
                                               this.curPage);
            else
               this.curBinder.addPage(this.curPage);
         }
         else if (id.equals(Stroke.class.getName()))
         {
            this.curStroke = new Stroke(new Pen(SCALE_LEVEL), 
                                        new Path(SCALE_LEVEL, 
                                                 SCALE_LEVEL));
            this.curPage.addStroke(this.curStroke);
         }
      }
      else if (localName.equals(RECT_TAG_NAME))
      {
         if (this.curPage == null)
         {
            System.err.println(NoteLabFileLoader.class.getName()+
                               " ERROR:  The start of a rectangle was found "+
                               "but a page hasn't been constructed yet.");
            this.curPage = new Page(PaperType.Plain, 
                                    SCALE_LEVEL, 
                                    SCALE_LEVEL);
         }
         
         Rectangle2D.Float rect = constructRectangle(attributes);
         this.curPage.x = rect.x;
         this.curPage.y = rect.y;
         this.curPage.width = rect.width;
         this.curPage.height = rect.height;
         
         String colorStr = attributes.getValue(FILL_NAME);
         if (this.curPage != null && !colorStr.toLowerCase().equals("none"))
         {
            Color bgColor = getColor(attributes, FILL_NAME);
            this.curPage.getPaper().setBackgroundColor(bgColor);
         }
      }
      else if (localName.equals(LINE_TAG_NAME))
      {
         if (this.lastID == null || 
             !this.lastID.equals(Stroke.class.getName()))
            return;
         
         if (this.curStroke == null)
         {
            System.err.println(NoteLabFileLoader.class.getName()+
                               " ERROR:  The start of a line was found " +
                               "but a stroke hasn't been constructed yet.");
            
            System.err.println("Local name = "+localName);
            System.err.println("Attributes");
            for (int i=0; i<attributes.getLength(); i++)
            {
               System.err.println(""+attributes.getLocalName(i)+"=\""+
                                  attributes.getValue(i)+"\"");
            }
            
            this.curStroke = new Stroke(new Pen(SCALE_LEVEL), 
                                        new Path(SCALE_LEVEL, 
                                                 SCALE_LEVEL));
            return;
         }
         
         Path path = this.curStroke.getPath();
         if (path.isEmpty())
         {
            path.addItem(constructPoint(attributes, 1));
            
            Color color = getColor(attributes, STROKE_NAME);
            float width = getLineWidth(attributes);
            
            Pen pen = this.curStroke.getPen();
            pen.setColor(color);
            pen.setWidth(width);
         }
         else
            path.addItem(constructPoint(attributes, 2));
      }
   }
   
   @Override
   public void endElement(String uri, String localName, 
                          String qName) throws SAXException
   {
      super.endElement(uri, localName, qName);
      
      if (this.lastID == null)
         return;
      
      if (this.lastID.equals(Stroke.class.getName()))
         this.curStroke.setIsStable(true);
   }

   @Override
   public void endDocument() throws SAXException
   {
      super.endDocument();
      
      this.curBinder.doLayout();
      
      CompositeCanvas canvas = 
         new CompositeCanvas(this.curBinder, SCALE_LEVEL);
      canvas.setFile(this.file);
      
      this.listener.noteLabFileLoaded(canvas);
   }
   
   private PaperType getPaperType(Attributes atts)
   {
      if (atts == null)
         throw new NullPointerException();
      
      String desc = atts.getValue(DESC_NAME);
      PaperType type = PaperType.Plain;
      if (desc.equals(PaperType.Plain.name()))
         type = PaperType.Plain;
      else if (desc.equals(PaperType.CollegeRuled.name()))
         type = PaperType.CollegeRuled;
      else if (desc.equals(PaperType.WideRuled.name()))
         type = PaperType.WideRuled;
      else if (desc.equals(PaperType.Graph.name()))
         type = PaperType.Graph;
      else
      {
         System.out.println(NoteLabFileLoader.class.getName()+
                            "ERROR:  The paper type '"+desc+
                            "' is not supported.  The default value '"+
                            type+"' will be used.");
      }
      
      return type;
   }
   
   private static Rectangle2D.Float constructRectangle(Attributes atts)
   {
      String xParam = atts.getValue("x");
      String yParam = atts.getValue("y");
      String widthParam = atts.getValue("width");
      String heightParam = atts.getValue("height");
      
      float x = getValue(xParam);
      float y = getValue(yParam);
      float width = getValue(widthParam);
      float height = getValue(heightParam);
      
      return new Rectangle2D.Float(x, y, width, height);
   }
   
   private static Color getColor(Attributes atts, String colorAtName)
   {
      if (atts == null)
         throw new NullPointerException();
      
      String colorStr = atts.getValue(colorAtName);
      if (colorStr.length() == 0)
         return Color.BLACK;
      
      colorStr = colorStr.substring(1);
      int rgb = 0;
      try
      {
         rgb = Integer.parseInt(colorStr, 16);
      }
      catch (NumberFormatException e)
      {
         System.out.println(NoteLabFileLoader.class.getName()+
                            "ERROR:  The value '#"+rgb+"' does not "+
                            "specify a valid color.  The default value '"+
                            rgb+"' will be used.");
      }
      
      return new Color(rgb);
   }
   
   private static float getLineWidth(Attributes atts)
   {
      if (atts == null)
         throw new NullPointerException();
      
      String widthStr = atts.getValue(STROKE_WIDTH_NAME);
      float width = 1;
      try
      {
         width = Float.parseFloat(widthStr);
      }
      catch (NumberFormatException e)
      {
         System.out.println(NoteLabFileLoader.class.getName()+
                            "ERROR:  The width '"+widthStr+"' is " +
                            "invalid the default value '"+width+
                            "' will be used.");
      }
      
      return width;
   }
   
   private FloatPoint2D constructPoint(Attributes atts, int num)
   {
      if (atts == null)
         throw new NullPointerException();
      
      String xParam = atts.getValue("x"+num);
      String yParam = atts.getValue("y"+num);
      
      return new FloatPoint2D(getValue(xParam), getValue(yParam), 
                              SCALE_LEVEL, SCALE_LEVEL);
   }
   
   private static float getValue(String mValStr)
   {
      if (mValStr == null)
         throw new NullPointerException();
      
      mValStr = mValStr.trim();
      if (mValStr.length() < 3)
         return 0;
      
      String unitStr = mValStr.substring(mValStr.length()-2).trim();
      String valStr = mValStr.substring(0, mValStr.length()-2).trim();
      
      Unit unit = Unit.INCH;
      if (unitStr.equals("in"))
         unit = Unit.INCH;
      else if (unitStr.equals("cm"))
         unit = Unit.CM;
      else if (unitStr.equals("px"))
         unit = Unit.PIXEL;
      else
      {
         System.out.println("LoadNoteLabFile:  Found an unsupported unit '"+
                            unitStr+"'.  Using the default unit '"+unit+"'.");
      }
      
      double val = 0;
      try
      {
         val = Double.parseDouble(valStr);
      }
      catch (NumberFormatException e)
      {
         System.out.println("LoadNoteLabFile:  The value '"+valStr+
                            "' is not a proper double precision number.  " +
                            "The default value of '"+val+"' will be used.");
      }
      
      return (float)val;
   }
}
