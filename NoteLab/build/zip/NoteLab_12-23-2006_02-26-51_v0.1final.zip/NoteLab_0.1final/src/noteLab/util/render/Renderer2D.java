/*
 *  NoteLab:  An advanced note taking application for pen-enabled platforms
 *  
 *  Copyright (C) 2006, Dominic Kramer
 *  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *  
 *  For any questions or comments please contact:  
 *    Dominic Kramer
 *    kramerd@iastate.edu
 */

package noteLab.util.render;

import java.awt.Color;
import java.awt.geom.Rectangle2D;
import java.util.Stack;

import noteLab.model.geom.FloatPoint2D;
import noteLab.util.Selectable;
import noteLab.util.geom.Bounded;
import noteLab.util.settings.DebugSettings;

/**
 * A class of this type, has the ability to render a display.  
 * Subclasses extend this class to implement the ability to 
 * render to a computer display, bitmapped image, or 
 * scalable vector graphics (SVG) image.
 * 
 * @author Dominic Kramer
 */
public abstract class Renderer2D implements Selectable
{
   private Stack<String> groupIDStack;
   private boolean selected;
   
   public Renderer2D()
   {
      this.groupIDStack = new Stack<String>();
      setSelected(false);
   }
   
   public boolean isSelected()
   {
      return this.selected;
   }
   
   public void setSelected(boolean selected)
   {
      this.selected = selected;
   }
   
   public void tryRenderBoundingBox(Bounded bounded)
   {
      if (!DebugSettings.getSharedInstance().displayBoundingBox())
         return;
      
      if (bounded == null)
         throw new NullPointerException();
      
      setColor(Color.RED);
      setLineWidth(1);
      drawRectangle(bounded.getBounds2D());
   }
   
   public void beginGroup(Renderable renderable, String desc, 
                          float xScaleLevel, float yScaleLevel)
   {
      if (renderable == null || desc == null)
         throw new NullPointerException();
      
      this.groupIDStack.push(renderable.getClass().getName());
      beginGroupImpl(renderable, desc, xScaleLevel, yScaleLevel);
   }
   
   public void endGroup(Renderable renderable)
   {
      if (renderable == null)
         throw new NullPointerException();
      
      String curName = renderable.getClass().getName();
      String grpOnStack = this.groupIDStack.pop();
      if (!grpOnStack.equals(curName))
         System.out.println("Renderer2D:  Warning:  Ended the group "+
                            curName+" while the last group that had " +
                            "begun was "+grpOnStack);
      
      endGroupImpl(renderable);
   }
   
   public static float getStrokeWidth(float width, boolean isSelected)
   {
      if (!isSelected)
         return width;
      
      return width+4;
   }
   
   public abstract void drawLine(FloatPoint2D pt1, FloatPoint2D pt2);
   public abstract void drawRectangle(Rectangle2D rect);
   public abstract void fillRectangle(Rectangle2D rect);
   
   public abstract void setColor(Color color);
   public abstract void setLineWidth(float width);
   public abstract float getLineWidth();
   
   public abstract void finish();
   
   public abstract void translate(float x, float y);
   public abstract void scale(float x, float y);
   
   public abstract boolean isInClipRegion(Bounded bounded);
   
   protected abstract void beginGroupImpl(Renderable renderable, 
                                          String desc, 
                                          float xScaleFactor, 
                                          float yScaleFactor);
   protected abstract void endGroupImpl(Renderable renderable);
}
