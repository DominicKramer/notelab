/*
 *  NoteLab:  An advanced note taking application for pen-enabled platforms
 *  
 *  Copyright (C) 2006, Dominic Kramer
 *  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *  
 *  For any questions or comments please contact:  
 *    Dominic Kramer
 *    kramerd@iastate.edu
 */

package noteLab.util.undoRedo;

import java.util.Vector;

import noteLab.util.FiniteStack;
import noteLab.util.undoRedo.action.HistoryAction;

public class UndoRedoManager
{
   private static final int HISTORY_SIZE = 25;
   
   private FiniteStack<UndoRedoAction> undoStack;
   private FiniteStack<UndoRedoAction> redoStack;
   
   private Vector<UndoRedoListener> listenerVec;
   
   public UndoRedoManager()
   {
      this.undoStack = 
         new FiniteStack<UndoRedoAction>(HISTORY_SIZE);
      this.redoStack = 
         new FiniteStack<UndoRedoAction>(HISTORY_SIZE);
      
      this.listenerVec = new Vector<UndoRedoListener>();
   }
   
   public void addUndoRedoListener(UndoRedoListener listener)
   {
      if (listener == null)
         throw new NullPointerException();
      
      if (!this.listenerVec.contains(listener))
         this.listenerVec.add(listener);
   }
   
   public void removeUndoRedoListener(UndoRedoListener listener)
   {
      if (listener == null)
         throw new NullPointerException();
      
      this.listenerVec.remove(listener);
   }
   
   private void notifyListeners()
   {
      for (UndoRedoListener listener : this.listenerVec)
         listener.undoRedoStackChanged(this);
   }
   
   public void actionDone(HistoryAction actionDone, HistoryAction undoAction)
   {
      if (actionDone == null || undoAction == null)
         throw new NullPointerException();
      
      this.undoStack.push(new UndoRedoAction(undoAction, actionDone));
      this.redoStack.clear();
      
      notifyListeners();
   }
   
   public boolean canUndo()
   {
      return !this.undoStack.isEmpty();
   }
   
   public void undo()
   {
      if (!canUndo())
         return;
      
      UndoRedoAction topAction = this.undoStack.pop();
      this.redoStack.push(topAction);
      
      topAction.getUndoAction().run();
      notifyListeners();
   }
   
   public boolean canRedo()
   {
      return !this.redoStack.isEmpty();
   }
   
   public void redo()
   {
      if (!canRedo())
         return;
      
      UndoRedoAction topAction = this.redoStack.pop();
      this.undoStack.push(topAction);
      
      topAction.getRedoAction().run();
      notifyListeners();
   }
   
   private static class UndoRedoAction
   {
      private HistoryAction undoAction;
      private HistoryAction redoAction;
      
      public UndoRedoAction(HistoryAction undoAction, 
                            HistoryAction redoAction)
      {
         if (undoAction == null || redoAction == null)
            throw new NullPointerException();
         
         this.undoAction = undoAction;
         this.redoAction = redoAction;
      }
      
      public HistoryAction getUndoAction()
      {
         return this.undoAction;
      }
      
      public HistoryAction getRedoAction()
      {
         return this.redoAction;
      }
   }
}
