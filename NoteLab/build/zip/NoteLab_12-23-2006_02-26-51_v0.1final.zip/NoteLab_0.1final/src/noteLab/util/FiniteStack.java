/*
 *  NoteLab:  An advanced note taking application for pen-enabled platforms
 *  
 *  Copyright (C) 2006, Dominic Kramer
 *  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *  
 *  For any questions or comments please contact:  
 *    Dominic Kramer
 *    kramerd@iastate.edu
 */

package noteLab.util;

public class FiniteStack<E>
{
   private E[] stackArr;
   private int curIndex;
   private int curLength;
   
   public FiniteStack(int size)
   {
      if (size <= 0)
         throw new IllegalArgumentException(
                      "The size of a stack cannot be " +
                      "zero or negative.  The requested " +
                      "size was "+size);
      
      this.stackArr = (E[])new Object[size];
      this.curLength = 0;
      this.curIndex = -1;
   }
   
   public int getSize()
   {
      return this.curLength;
   }
   
   public boolean isEmpty()
   {
      return getSize() == 0;
   }
   
   public E peek()
   {
      if (isEmpty())
         return null;
      
      return this.stackArr[this.curIndex];
   }
   
   public E pop()
   {
      E top = peek();
      if (top == null)
         return null;
      
      this.curIndex = calcIndex(this.curIndex, false);
      this.curLength--;
      return top;
   }
   
   public E push(E ob)
   {
      this.curIndex = calcIndex(this.curIndex, true);
      this.stackArr[this.curIndex] = ob;
      this.curLength++;
      if (this.curLength > this.stackArr.length)
         this.curLength = this.stackArr.length;
         
      return ob;
   }
   
   public void clear()
   {
      this.curIndex = -1;
      this.curLength = 0;
   }
   
   public String debugToString()
   {
      if (isEmpty())
         return "The stack is empty.";
      
      StringBuffer buffer = 
         new StringBuffer("The stack contains:  ");
      
      E[] stackArrCp = (E[])new Object[this.stackArr.length];
      System.arraycopy(this.stackArr, 0, stackArrCp, 0, 
                       this.stackArr.length);
      
      FiniteStack<E> stackCp = 
         new FiniteStack<E>(this.stackArr.length);
      stackCp.stackArr = stackArrCp;
      stackCp.curIndex = this.curIndex;
      stackCp.curLength = this.curLength;
      
      E top;
      while ( (top = stackCp.pop()) != null)
      {
         buffer.append("{");
         buffer.append(top.toString());
         buffer.append("} ");
      }
      
      return buffer.toString();
   }
   
   @Override
   public String toString()
   {
      StringBuffer buffer = 
         new StringBuffer("Stack; size=");
      
      buffer.append(getSize());
      
      if (isEmpty())
         return buffer.toString();
      
      buffer.append(" contents=");
      
      int length = this.curLength;
      int index = this.curIndex;
      while (length > 0)
      {
         buffer.append("{");
         buffer.append(this.stackArr[index]);
         buffer.append("} ");
         
         index = calcIndex(index, false);
         length--;
      }
      
      return buffer.toString();
   }
   
   private int calcIndex(int index, boolean increase)
   {
      if (increase)
         return (index+1)%this.stackArr.length;
      
      if (index > 0)
         return index-1;
      
      return this.stackArr.length-1;
   }
   
   public static void main(String[] args)
   {
      FiniteStack<String> stack = new FiniteStack<String>(5);
      System.out.println("Pushing '1' onto the stack");
      stack.push("1");
      System.out.println(stack.debugToString());
      
      System.out.println("Pushing '2' onto the stack");
      stack.push("2");
      System.out.println(stack.debugToString());
      
      System.out.println("Pushing '3' onto the stack");
      stack.push("3");
      System.out.println(stack.debugToString());
      
      System.out.println("Pushing '4' onto the stack");
      stack.push("4");
      System.out.println(stack.debugToString());
      
      System.out.println("Pushing '5' onto the stack");
      stack.push("5");
      System.out.println(stack.debugToString());
      
      System.out.println("Pushing '6' onto the stack");
      stack.push("6");
      System.out.println(stack.debugToString());
      
      System.out.println("Pushing '7' onto the stack");
      stack.push("7");
      System.out.println(stack.debugToString());
      
      System.out.println("Pop = "+stack.pop());
      System.out.println(stack.debugToString());
      
      System.out.println("Pop = "+stack.pop());
      System.out.println(stack.debugToString());
      
      System.out.println("Pop = "+stack.pop());
      System.out.println(stack.debugToString());
      
      System.out.println("Pop = "+stack.pop());
      System.out.println(stack.debugToString());
      
      System.out.println("Pop = "+stack.pop());
      System.out.println(stack.debugToString());
      
      System.out.println("Pop = "+stack.pop());
      System.out.println(stack.debugToString());
      
      System.out.println("Pop = "+stack.pop());
      System.out.println(stack.debugToString());
      
      System.out.println("Pushing '1' onto the stack");
      stack.push("1");
      System.out.println(stack.debugToString());
      
      System.out.println("Pushing '2' onto the stack");
      stack.push("2");
      System.out.println(stack.debugToString());
      
      System.out.println("Pushing '3' onto the stack");
      stack.push("3");
      System.out.println(stack.debugToString());
      
      System.out.println("Pushing '4' onto the stack");
      stack.push("4");
      System.out.println(stack.debugToString());
      
      System.out.println("Clearing the stack");
      stack.clear();
      System.out.println(stack.debugToString());
      
      System.out.println("Pushing '5' onto the stack");
      stack.push("5");
      System.out.println(stack.debugToString());
      
      System.out.println("Pushing '6' onto the stack");
      stack.push("6");
      System.out.println(stack.debugToString());
      
      System.out.println("Pushing '7' onto the stack");
      stack.push("7");
      System.out.println(stack.debugToString());
   }
}
