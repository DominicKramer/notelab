/*
 *  NoteLab:  An advanced note taking application for pen-enabled platforms
 *  
 *  Copyright (C) 2006, Dominic Kramer
 *  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *  
 *  For any questions or comments please contact:  
 *    Dominic Kramer
 *    kramerd@iastate.edu
 */

package noteLab.util.render;

import java.awt.Color;
import java.awt.geom.Rectangle2D;

import noteLab.model.geom.FloatPoint2D;
import noteLab.util.geom.Bounded;
import noteLab.util.geom.unit.Unit;

public class SVGRenderer2D extends Renderer2D
{
   private static final String XML_SPEC = 
                                  "<?xml version=\"1.0\" standalone=\"no\"?>";
   private static final String SVG_SPEC = "";
                                  //"<!DOCTYPE svg PUBLIC \"-//W3C//DTD " +
                                  //"SVG 1.1//EN\" \"http://www.w3.org/" +
                                  //"Graphics/SVG/1.1/DTD/svg11.dtd\">";
   private static final String SVG_VERSION_ATTR = "version=\"1.1\"";
   private static final String SVG_NAMESPACE_ATTR = 
                                  "xmlns=\"http://www.w3.org/2000/svg\"";
   
   private float width;
   private String color;
   private StringBuffer buffer;
   private StringBuffer transformBuffer;
   
   public SVGRenderer2D(Bounded boundsDesc)
   {
      this.width = 1;
      this.color = "black";
      this.buffer = new StringBuffer();
      this.transformBuffer = new StringBuffer();
      
      Rectangle2D bounds = boundsDesc.getBounds2D();
      
      float boundWidthPx = (float)bounds.getWidth();
      float boundHeightPx = (float)bounds.getHeight();
      
      initializeCode(boundWidthPx, boundHeightPx);
   }
   
   private void initializeCode(float boundWidthPx, float boundHeightPx)
   {
      this.buffer.append(XML_SPEC);
      this.buffer.append(SVG_SPEC);
      
      this.buffer.append("<svg width=\"");
      this.buffer.append(boundWidthPx);
      this.buffer.append("px\" height=\"");
      this.buffer.append(boundHeightPx);
      this.buffer.append("px\" ");
      this.buffer.append(SVG_VERSION_ATTR);
      this.buffer.append(" ");
      this.buffer.append(SVG_NAMESPACE_ATTR);
      this.buffer.append(">");
   }
   
   public String getSVGCode()
   {
      return this.buffer.toString();
   }
   
   @Override
   public void drawLine(FloatPoint2D pt1, FloatPoint2D pt2)
   {
      if (pt1 == null || pt2 == null)
         throw new NullPointerException();
      
      this.buffer.append("<line ");
      appendLocation(pt1, "1");
      appendSpace();
      appendLocation(pt2, "2");
      this.buffer.append(" stroke-width=\"");
      this.buffer.append(this.width);
      this.buffer.append("\" stroke=\"");
      this.buffer.append(this.color.toString());
      this.buffer.append("\" />");
   }

   @Override
   public void drawRectangle(Rectangle2D rect)
   {
      renderRectangle(rect, false);
   }

   @Override
   public void fillRectangle(Rectangle2D rect)
   {
      renderRectangle(rect, true);
   }
   
   private void renderRectangle(Rectangle2D rect, boolean fill)
   {
      if (rect == null)
         throw new NullPointerException();
      
      this.buffer.append("<rect ");
      appendLocation((float)rect.getX(), (float)rect.getY(), "");
      appendSpace();
      appendSize(rect);
      appendSpace();
      
      String fillName = "none";
      if (fill)
         fillName = this.color.toString();
      this.buffer.append("fill=\"");
      this.buffer.append(fillName);
      this.buffer.append("\" stroke=\"");
      this.buffer.append(this.color.toString());
      this.buffer.append("\" stroke-width=\"");
      this.buffer.append(this.width);
      this.buffer.append("\" />");
   }

   @Override
   public void setColor(Color color)
   {
      if (color == null)
         throw new NullPointerException();
      
      String r = fixColorValue(Integer.toHexString(color.getRed()));
      String g = fixColorValue(Integer.toHexString(color.getGreen()));
      String b = fixColorValue(Integer.toHexString(color.getBlue()));
      
      this.color = "#"+r+g+b;
   }
   
   private static String fixColorValue(String val)
   {
      if (val == null)
         throw new NullPointerException();
      
      String newVal = "";
      if (val.length() == 1)
         newVal += "0";
      newVal += val;
      
      return newVal;
   }
   
   @Override
   public void setLineWidth(float width)
   {
      this.width = width;
   }
   
   @Override
   public float getLineWidth()
   {
      return this.width;
   }
   
   @Override
   protected void beginGroupImpl(Renderable renderable, String desc, 
                                 float xScaleLevel, float yScaleLevel)
   {
      this.buffer.append("<g id=\"");
      this.buffer.append(renderable.getClass().getName());
      this.buffer.append("\" desc=\"");
      this.buffer.append(desc);
      
      // Add any transforms if there are any
      String transformStr = this.transformBuffer.toString().trim();
      if (transformStr.length() > 0)
      {
         this.buffer.append("\" transform=\"");
         this.buffer.append(transformStr);
         this.transformBuffer.setLength(0);
      }
      this.buffer.append("\">");
   }

   @Override
   protected void endGroupImpl(Renderable renderable)
   {
      this.buffer.append("</g>");
   }
   
   @Override
   public void finish()
   {
      this.buffer.append("</svg>");
   }
   
   private void appendSpace()
   {
      this.buffer.append(" ");
   }
   
   private void appendValue(String label, float pxVal)
   {
      if (label == null)
         throw new NullPointerException();
      
      this.buffer.append(label);
      this.buffer.append("=\"");
      this.buffer.append(pxVal);
      appendSpace();
      this.buffer.append(Unit.PIXEL.toString());
      this.buffer.append("\"");
   }
   
   private void appendSize(Rectangle2D rect)
   {
      if (rect == null)
         throw new NullPointerException();
      
      float width = (float)rect.getWidth();
      float height = (float)rect.getHeight();
      
      appendValue("width", width);
      appendSpace();
      appendValue("height", height);
   }
   
   private void appendLocation(FloatPoint2D pt, String suffix)
   {
      if (pt == null)
         throw new NullPointerException();
      
      appendLocation(pt.x, pt.y, suffix);
   }
   
   private void appendLocation(float x, float y, String suffix)
   {
      if (suffix == null)
         throw new NullPointerException();
      
      appendValue("x"+suffix, x);
      appendSpace();
      appendValue("y"+suffix, y);
   }
   
   @Override
   public void scale(float x, float y)
   {
      this.transformBuffer.append("scale(");
      this.transformBuffer.append(x);
      this.transformBuffer.append(",");
      this.transformBuffer.append(y);
      this.transformBuffer.append(") ");
   }

   @Override
   public void translate(float x, float y)
   {
      this.transformBuffer.append("translate(");
      this.transformBuffer.append(x);
      this.transformBuffer.append(",");
      this.transformBuffer.append(y);
      this.transformBuffer.append(") ");
   }

   @Override
   public boolean isInClipRegion(Bounded bounded)
   {
      return true;
   }
}
