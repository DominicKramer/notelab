/*
 *  NoteLab:  An advanced note taking application for pen-enabled platforms
 *  
 *  Copyright (C) 2006, Dominic Kramer
 *  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *  
 *  For any questions or comments please contact:  
 *    Dominic Kramer
 *    kramerd@iastate.edu
 */

package noteLab.gui.main;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import java.util.Vector;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

import noteLab.gui.DefinedIcon;
import noteLab.gui.ToolBarButton;
import noteLab.gui.help.HelpMenu;
import noteLab.gui.menu.DynamicMenuBar;
import noteLab.gui.menu.MenuConstants;
import noteLab.gui.menu.Menued;
import noteLab.gui.menu.PathMenuItem;
import noteLab.gui.toolbar.BinderToolBar;
import noteLab.gui.toolbar.CanvasControlToolBar;
import noteLab.gui.toolbar.FileToolBar;
import noteLab.gui.toolbar.UndoRedoToolBar;
import noteLab.model.canvas.CompositeCanvas;
import noteLab.util.InfoCenter;
import noteLab.util.mod.ModListener;
import noteLab.util.mod.ModType;
import noteLab.util.settings.SettingsManager;
import noteLab.util.undoRedo.UndoRedoManager;

public class MainFrame extends JFrame implements Menued, 
                                                 ActionListener, 
                                                 ModListener
{
   private static int NUM_OPEN = 0;
   
   private static final String EXIT = "exit";
   
   private String title;
   private String modTitle;
   
   private JPanel toolbarPanel;
   private CompositeCanvas canvas;
   private FileToolBar fileToolBar;
   private Vector<PathMenuItem> menuItemVec;
   private MainFrameCloseListener closeListener;
   
   public MainFrame()
   {
      this(new CompositeCanvas(1));
   }
   
   public MainFrame(CompositeCanvas canvas)
   {
      if (canvas == null)
         throw new NullPointerException();
      
      setIconImage(DefinedIcon.feather.getIcon(24).getImage());
      
      //make the exit item on the file menu
      this.menuItemVec = new Vector<PathMenuItem>(1);
      
      JMenuItem exitItem = 
         new JMenuItem("Exit", DefinedIcon.quit.getIcon(16));
      exitItem.setActionCommand(EXIT);
      exitItem.addActionListener(this);
      
      this.menuItemVec.add(new PathMenuItem(exitItem, 
                                            MenuConstants.FILE_MENU_PATH));
      
      this.canvas = canvas;
      this.canvas.addModListener(this);
      
      JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        this.fileToolBar = new FileToolBar(this);
        topPanel.add(fileToolBar);
        
        UndoRedoManager manager = this.canvas.getUndoRedoManager();
        UndoRedoToolBar undoRedoToolBar = new UndoRedoToolBar(manager);
        topPanel.add(undoRedoToolBar);
        
        BinderToolBar binderToolBar = new BinderToolBar(this.canvas);
        topPanel.add(binderToolBar);
        
      JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
      bottomPanel.add(new CanvasControlToolBar(this.canvas));
      
      this.toolbarPanel = new JPanel();
      this.toolbarPanel.setLayout(new BoxLayout(this.toolbarPanel, 
                                                BoxLayout.Y_AXIS));
      this.toolbarPanel.add(topPanel);
      this.toolbarPanel.add(bottomPanel);
      
      setLayout(new BorderLayout());
      add(this.toolbarPanel, BorderLayout.NORTH);
      add(new MainPanel(this.canvas));
      
      // now configure the menu bar
      DynamicMenuBar menuBar = new DynamicMenuBar();
      
      Vector<ToolBarButton> toolBars = this.canvas.getToolBars();
      menuBar.addMenued(this.fileToolBar);
      menuBar.addMenued(this);
      
      for (ToolBarButton toolBar : toolBars)
         menuBar.addMenued(toolBar);
      
      menuBar.addMenued(new HelpMenu());
      
      setJMenuBar(menuBar);
      
      this.closeListener = new MainFrameCloseListener();
      addWindowListener(this.closeListener);
      this.closeListener.windowOpened();
      
      this.title = InfoCenter.getAppName()+" Version "+
                     InfoCenter.getAppVersion();
      
      NUM_OPEN++;
      if (NUM_OPEN > 1)
         this.title += " Window "+NUM_OPEN;
      setTitle(this.title);
      
      this.modTitle = this.title+" (Modified)";
      
      setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
      setSize(900, 1000);
      
      SettingsManager.getSharedInstance().notifyOfChanges();
   }
   
   public CompositeCanvas getCompositeCanvas()
   {
      return this.canvas;
   }
   
   public List<PathMenuItem> getPathMenuItems()
   {
      return this.menuItemVec;
   }

   public void actionPerformed(ActionEvent e)
   {
      this.closeListener.processWindowClosing();
   }
   
   private class MainFrameCloseListener extends WindowAdapter
   {
      public MainFrameCloseListener()
      {
      }
      
      public void windowOpened()
      {
      }
      
      public void windowClosing(WindowEvent e)
      {
         processWindowClosing();
      }
      
      private void processWindowClosing()
      {
         if (canvas.hasBeenModified())
         {
            int result = 
                  JOptionPane.
                     showConfirmDialog(new JFrame(), "Save changes?", "Save?", 
                                       JOptionPane.YES_NO_CANCEL_OPTION, 
                                       JOptionPane.QUESTION_MESSAGE, 
                                       DefinedIcon.dialog_question.
                                                      getIcon(48));
            
            if (result == JOptionPane.CANCEL_OPTION)
               return;
            
            if (result == JOptionPane.YES_OPTION)
            {
               // The argument 'false' is used so that the "save as" option is 
               // not forced.  That is, if the user has already saved the 
               // current canvas to a file, the user won't be asked to again 
               // select a file.  Instead it will use the current file.
               if (!fileToolBar.save(false))
                  return;
            }
         }
         
         dispose();
         NUM_OPEN--;
         if (NUM_OPEN == 0)
            System.exit(0);
      }
   }
   
   public void hasBeenSaved()
   {
      setTitle(this.title);
      this.canvas.setHasBeenModified(false);
   }

   public void modOccured(Object source, ModType type)
   {
      String curTitle = getTitle();
      if (!curTitle.equals(this.modTitle))
         setTitle(this.modTitle);
   }
}
