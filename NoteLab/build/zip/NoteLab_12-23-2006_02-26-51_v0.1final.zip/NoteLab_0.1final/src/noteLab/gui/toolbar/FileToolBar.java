/*
 *  NoteLab:  An advanced note taking application for pen-enabled platforms
 *  
 *  Copyright (C) 2006, Dominic Kramer
 *  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *  
 *  For any questions or comments please contact:  
 *    Dominic Kramer
 *    kramerd@iastate.edu
 */

package noteLab.gui.toolbar;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.JToolBar;

import noteLab.gui.DefinedIcon;
import noteLab.gui.GuiSettingsConstants;
import noteLab.gui.chooser.ImageFileFilter;
import noteLab.gui.chooser.NoteLabFileChooser;
import noteLab.gui.chooser.NoteLabFileFilter;
import noteLab.gui.main.MainFrame;
import noteLab.gui.menu.MenuConstants;
import noteLab.gui.menu.Menued;
import noteLab.gui.menu.PathMenuItem;
import noteLab.gui.settings.SettingsFrame;
import noteLab.model.binder.Binder;
import noteLab.model.canvas.CompositeCanvas;
import noteLab.util.InfoCenter;
import noteLab.util.io.NoteLabFileLoadedListener;
import noteLab.util.io.NoteLabFileLoader;
import noteLab.util.render.ImageRenderer2D;
import noteLab.util.render.SVGRenderer2D;

public class FileToolBar 
                extends JToolBar 
                           implements ActionListener, 
                                      Menued, 
                                      NoteLabFileLoadedListener, 
                                      GuiSettingsConstants
{
   private static final String NEW = "new";
   private static final String SAVE = "save";
   private static final String SAVE_AS = "save as";
   private static final String OPEN = "open";
   private static final String EXPORT = "export";
   private static final String PRINT = "print";
   private static final String SETTINGS = "settings";
   
   private MainFrame mainFrame;
   private Vector<PathMenuItem> menuItemVec;
   
   public FileToolBar(MainFrame mainFrame)
   {
      if (mainFrame == null)
         throw new NullPointerException();
      
      this.mainFrame = mainFrame;
      
      JButton saveButton = 
         new JButton(DefinedIcon.floppy.getIcon(BUTTON_SIZE));
      saveButton.addActionListener(this);
      saveButton.setActionCommand(SAVE);
      
      JButton newButton = 
         new JButton(DefinedIcon.page.getIcon(BUTTON_SIZE));
      newButton.addActionListener(this);
      newButton.setActionCommand(NEW);
      
      JButton openButton = 
         new JButton(DefinedIcon.directory.getIcon(BUTTON_SIZE));
      openButton.addActionListener(this);
      openButton.setActionCommand(OPEN);
      
      JButton exportButton = 
         new JButton(DefinedIcon.image_page.getIcon(BUTTON_SIZE));
      exportButton.addActionListener(this);
      exportButton.setActionCommand(EXPORT);
      
      JButton printButton = 
         new JButton(DefinedIcon.print.getIcon(BUTTON_SIZE));
      printButton.addActionListener(this);
      printButton.setActionCommand(PRINT);
      
      add(newButton);
      add(openButton);
      add(saveButton);
      add(exportButton);
      add(printButton);
      
      //make the menu items
      this.menuItemVec = new Vector<PathMenuItem>();
      
      ImageIcon newIcon = DefinedIcon.page.getIcon(16);
      ImageIcon openIcon = DefinedIcon.directory.getIcon(16);
      ImageIcon saveIcon = DefinedIcon.floppy.getIcon(16);
      ImageIcon saveAsIcon = DefinedIcon.save_as.getIcon(16);
      ImageIcon exportIcon = DefinedIcon.image_page.getIcon(16);
      ImageIcon printIcon = DefinedIcon.print.getIcon(16);
      ImageIcon settingsIcon = DefinedIcon.preferences.getIcon(16);
      
      //make the menu items
      JMenuItem newItem = new JMenuItem("New", newIcon);
      newItem.setActionCommand(NEW);
      newItem.addActionListener(this);
      
      JMenuItem openItem = new JMenuItem("Open", openIcon);
      openItem.setActionCommand(OPEN);
      openItem.addActionListener(this);
      
      JMenuItem saveItem = new JMenuItem("Save", saveIcon);
      saveItem.setActionCommand(SAVE);
      saveItem.addActionListener(this);
      
      JMenuItem saveAsItem = new JMenuItem("Save As", saveAsIcon);
      saveAsItem.setActionCommand(SAVE_AS);
      saveAsItem.addActionListener(this);
      
      JMenuItem exportItem = new JMenuItem("Export", exportIcon);
      exportItem.setActionCommand(EXPORT);
      exportItem.addActionListener(this);
      
      JMenuItem printItem = new JMenuItem("Print", printIcon);
      printItem.setActionCommand(PRINT);
      printItem.addActionListener(this);
      
      JMenuItem settingsItem = new JMenuItem("Settings", settingsIcon);
      settingsItem.setActionCommand(SETTINGS);
      settingsItem.addActionListener(this);
      
      //add the menu items to the menu vector
      this.menuItemVec.add(new PathMenuItem(newItem, 
                                            MenuConstants.FILE_MENU_PATH));
      this.menuItemVec.add(new PathMenuItem(openItem, 
                                            MenuConstants.FILE_MENU_PATH));
      this.menuItemVec.add(new PathMenuItem(new JSeparator(), 
                                            MenuConstants.FILE_MENU_PATH));
      this.menuItemVec.add(new PathMenuItem(saveItem, 
                                            MenuConstants.FILE_MENU_PATH));
      this.menuItemVec.add(new PathMenuItem(saveAsItem, 
                                            MenuConstants.FILE_MENU_PATH));
      this.menuItemVec.add(new PathMenuItem(new JSeparator(), 
                                            MenuConstants.FILE_MENU_PATH));
      this.menuItemVec.add(new PathMenuItem(exportItem, 
                                            MenuConstants.FILE_MENU_PATH));
      this.menuItemVec.add(new PathMenuItem(new JSeparator(), 
                                            MenuConstants.FILE_MENU_PATH));
      this.menuItemVec.add(new PathMenuItem(printItem, 
                                            MenuConstants.FILE_MENU_PATH));
      this.menuItemVec.add(new PathMenuItem(new JSeparator(), 
                                            MenuConstants.FILE_MENU_PATH));
      this.menuItemVec.add(new PathMenuItem(settingsItem, 
                                            MenuConstants.FILE_MENU_PATH));
      this.menuItemVec.add(new PathMenuItem(new JSeparator(), 
                                            MenuConstants.FILE_MENU_PATH));
   }
   
   public List<PathMenuItem> getPathMenuItems()
   {
      return this.menuItemVec;
   }
   
   public void actionPerformed(ActionEvent e)
   {
      CompositeCanvas canvas = this.mainFrame.getCompositeCanvas();
      
      String cmmd = e.getActionCommand();
      if (cmmd.equals(NEW))
      {
         new MainFrame().setVisible(true);
      }
      else if (cmmd.equals(OPEN))
      {
         NoteLabFileChooser openChooser = new NoteLabFileChooser();
         openChooser.setFileFilter(new NoteLabFileFilter());
         
         int ret = openChooser.showOpenDialog(new JFrame());
         if (ret == JFileChooser.APPROVE_OPTION)
         {
            File file = openChooser.getSelectedFile();
            if (file == null)
               return;
            
            try
            {
               NoteLabFileLoader loader = new NoteLabFileLoader(file, this);
               loader.loadFile();
            }
            catch (Exception exception)
            {
               notifyOfException(exception);
            }
         }
      }
      else if (cmmd.equals(SAVE))
      {
         // the boolean argument is false so that saving doesn't force 
         // the "save as" option
         save(false);
      }
      else if (cmmd.equals(SAVE_AS))
      {
         // the boolean argument is true so that saving forces  
         // the "save as" option
         save(true);
      }
      else if (cmmd.equals(EXPORT))
      {
         NoteLabFileChooser exportChooser = new NoteLabFileChooser();
         exportChooser.setApproveButtonText("Export");
         exportChooser.setApproveButtonToolTipText(
                          "Export to the selected file");
         exportChooser.setDialogTitle("Export?");
         exportChooser.setFileFilter(new ImageFileFilter());
         
         int ret = exportChooser.showSaveDialog(new JFrame());
         if (ret == JFileChooser.APPROVE_OPTION)
         {
            File file = exportChooser.getSelectedFile();
            if (file == null)
               return;
            
            Binder binder = canvas.getBinder();
            float width = binder.getWidth();
            float height = binder.getHeight();
            
            BufferedImage image = 
               new BufferedImage( (int)width, (int)height, 
                                  BufferedImage.TYPE_INT_ARGB );
            ImageRenderer2D image2D = new ImageRenderer2D(image);
            canvas.renderInto(image2D);
            
            String ext = null;
            String path = file.getPath().toLowerCase();
            for (String fileExt : ImageFileFilter.EXT_ARR)
            {
               if (path.endsWith(fileExt.toLowerCase()))
               {
                  ext = fileExt;
                  break;
               }
            }
            
            // if a valid extension isn't given, use a default
            if (ext == null)
            {
               String defaultExt = "png";
               ext = defaultExt;
               file = new File(file.getAbsolutePath()+"."+ext);
            }
            
            if (ext.equalsIgnoreCase("svg"))
            {
               saveAsSVG(file, ".svg");
               return;
            }
            
            try
            {
               ImageIO.write(image, ext, file);
            }
            catch (IOException exception)
            {
               notifyOfException(exception);
            }
         }
      }
      else if (cmmd.equals(PRINT))
      {
         PrinterJob printerJob = PrinterJob.getPrinterJob();
         printerJob.setPageable(canvas.getBinder());
         
         boolean notCancelled = printerJob.printDialog();
         if (notCancelled)
         {
            try
            {
               printerJob.print();
            }
            catch (PrinterException printEx)
            {
               notifyOfException(printEx);
            }
         }
      }
      else if (cmmd.equals(SETTINGS))
      {
         new SettingsFrame().setVisible(true);
      }
   }
   
   public boolean save(boolean forceSaveAs)
   {
      File file = this.mainFrame.getCompositeCanvas().getFile();
      if (!forceSaveAs && file != null)
      {
         saveAsSVG(file, ".ntlb");
         return true;
      }
      
      NoteLabFileChooser saveChooser = new NoteLabFileChooser();
      saveChooser.setFileFilter(new NoteLabFileFilter());
      
      int ret = saveChooser.showSaveDialog(new JFrame());
      if (ret == JFileChooser.APPROVE_OPTION)
      {
         File newFile = saveChooser.getSelectedFile();
         if (newFile == null)
            return false;
         
         saveAsSVG(newFile, InfoCenter.getFileExtension());
         return true;
      }
      
      return false;
   }
   
   private void saveAsSVG(File file, String ext)
   {
      if (file == null || ext == null)
         throw new NullPointerException();
      
      String fullPath = file.getAbsolutePath();
      if (!fullPath.toLowerCase().endsWith(ext.toLowerCase()))
      {
         fullPath += ext;
         file = new File(fullPath);
      }
      
      CompositeCanvas canvas = this.mainFrame.getCompositeCanvas();
      float zoomFactor = canvas.getZoomLevel();
      canvas.setZoomFactor(1);
      
      SVGRenderer2D msvg2D = new SVGRenderer2D(canvas);
      canvas.renderInto(msvg2D);
      String svgCode = msvg2D.getSVGCode();
      
      try
      {
         if (!file.exists())
            file.createNewFile();
         
         PrintWriter writer = 
                        new PrintWriter(new FileOutputStream(file));
         writer.println(svgCode);
         writer.close();
         
         canvas.setFile(file);
         canvas.setZoomFactor(zoomFactor);
         this.mainFrame.hasBeenSaved();
      }
      catch (IOException exception)
      {
         notifyOfException(exception);
      }
   }

   public void noteLabFileLoaded(CompositeCanvas canvas)
   {
      new MainFrame(canvas).setVisible(true);
   }
   
   private static void notifyOfException(Exception exception)
   {
      new JOptionPane(exception.getLocalizedMessage(), 
                      JOptionPane.ERROR_MESSAGE);
   }
}
