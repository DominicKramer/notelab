The icon set used in NoteLab is based on the Dropline Neu 
icon set developed by Silvestre Herrera.  See the 
accompanying file "license.txt" for the complete license 
for the Dropline Neu icon set.
